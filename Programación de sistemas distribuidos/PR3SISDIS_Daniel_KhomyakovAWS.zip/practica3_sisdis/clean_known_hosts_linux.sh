ssh-keygen -f "/home/raul/.ssh/known_hosts" -R "ec2-34-202-41-76.compute-1.amazonaws.com"
ssh-keygen -f "/home/raul/.ssh/known_hosts" -R "34.202.41.76"
