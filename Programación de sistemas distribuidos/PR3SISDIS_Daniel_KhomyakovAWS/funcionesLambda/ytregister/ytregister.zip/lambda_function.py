import sys
import logging
import pymysql
import json
import hashlib

rds_host = "34.202.41.76"

username = "admin"
password ="password"
dbname = "youtube"

try:
    conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
except pymysql.MySQLError as e:
    print (e)
    sys.exit()

def lambda_handler(event , context):
    name=event["queryStringParameters"]["name"];
    username=event["queryStringParameters"]["username"];
    email=event["queryStringParameters"]["email"];
    passwd=event["queryStringParameters"]["passwd"];
    result=0;
    resultadosBD = 0;
    redirectPage="";
    isCorrect = 0;


    try:
        colaUsuariosCheck = [];
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM usuarios WHERE username ='" +username + "'")
            resultadosBD = cur.fetchall()

            for row in resultadosBD:
                for x in row:
                    colaUsuariosCheck.append(x)

            if (username) in colaUsuariosCheck:
                print('No se puede registrar el usuario porque ya existe')
                redirectPage="http://" +rds_host+ "/ytregister.html";
            else:
                hashPasswd = hashlib.md5(passwd.encode())
                cur.execute("insert into usuarios values ('" +name+ "','" +username+ "','" +email+ "','" +hashPasswd.hexdigest()+ "')")
                conn.commit()
                redirectPage="http://" +rds_host+ "/home.html";
    except pymysql.MySQLError as e:
        print (e)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : json.dumps( {'redirect': redirectPage} )
    }
