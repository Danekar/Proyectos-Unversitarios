#Daniel Khomyakov y Raul Martinez Llorente

sudo docker image rm -f raulmllorente/filemanager:1.0
