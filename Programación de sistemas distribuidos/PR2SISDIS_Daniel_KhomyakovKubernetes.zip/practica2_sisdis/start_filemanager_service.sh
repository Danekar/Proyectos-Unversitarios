#Daniel Khomyakov y Raul Martinez Llorente

kubectl apply -f filemanager_service.yaml
