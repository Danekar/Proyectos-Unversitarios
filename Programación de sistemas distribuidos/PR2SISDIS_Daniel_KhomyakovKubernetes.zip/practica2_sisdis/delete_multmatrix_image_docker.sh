#Daniel Khomyakov y Raul Martinez Llorente

sudo docker image rm -f raulmllorente/multmatrix:1.0
