#Daniel Khomyakov y Raul Martinez Llorente

kubectl delete service multmatrix-service
kubectl delete service filemanager-service
