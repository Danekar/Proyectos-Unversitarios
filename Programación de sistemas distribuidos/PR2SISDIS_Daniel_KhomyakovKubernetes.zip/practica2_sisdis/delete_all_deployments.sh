#Daniel Khomyakov y Raul Martinez Llorente

kubectl delete deployment multmatrix
kubectl delete deployment filemanager
