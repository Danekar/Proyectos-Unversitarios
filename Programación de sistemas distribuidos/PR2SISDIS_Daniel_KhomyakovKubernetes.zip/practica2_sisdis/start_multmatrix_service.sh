#Daniel Khomyakov y Raul Martinez Llorente

kubectl apply -f multmatrix_service.yaml
