#Daniel Khomyakov y Raul Martinez Llorente

sudo rm -r vol-filemanager
sudo mkdir vol-filemanager
sudo chmod a+rwx vol-filemanager
